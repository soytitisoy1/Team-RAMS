package com.kabantay;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class HulicaMainActivity extends Activity {
	 WebView wv;	
	 WebSettings wSettings;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_hulica_main);
		Toast.makeText(this, "Login successfull!", 500).show();
	    wv = new WebView(this);
	    wv.setClickable(true);
	    wSettings = wv.getSettings();
	    wSettings.setJavaScriptEnabled(true);
wv.loadUrl("file:///android_asset/index.html");    
		setContentView(wv);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.hulica_main, menu);
		return true;
	}

}
