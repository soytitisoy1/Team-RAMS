package com.kabantay;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends Activity {
	 WebView wv;	
	 WebSettings wSettings;
	  @SuppressLint("SetJavaScriptEnabled")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void guide(View v) {
	       Intent intent = new Intent(this, GuideDocActivity.class);
	       startActivity(intent);
		
		/*
		Toast.makeText(this, "webView", 500).show();
			    wv = new WebView(this);
			    wv.setClickable(true);
			    wSettings = wv.getSettings();
			    wSettings.setJavaScriptEnabled(true);
   wv.loadUrl("file:///android_asset/index.html");    
				setContentView(wv);
		
	*/
	}
	public void loginui(View v) {
//				setContentView(R.layout.login);
	       Intent intent = new Intent(this, LoginActivity.class);
	       startActivity(intent);

	}
	public void register(View v) {
//		setContentView(R.layout.login);
   Intent intent = new Intent(this, RegistrationActivity.class);
   startActivity(intent);

}
	
	public void about(View v) {
//		setContentView(R.layout.about);
//		setContentView(R.layout.login);
   Intent intent = new Intent(this, AboutActivity.class);
   startActivity(intent);

	}
	public void back(View v) {
		setContentView(R.layout.activity_main);
	}

	public void loginprocess(View v) {
       Intent intent = new Intent(this, HulicaMainActivity.class);
       startActivity(intent);
		/*		Toast.makeText(this, "Login successfull!", 500).show();
			    wv = new WebView(this);
			    wv.setClickable(true);
			    wSettings = wv.getSettings();
			    wSettings.setJavaScriptEnabled(true);
   wv.loadUrl("file:///android_asset/index.html");    
				setContentView(wv);
	*/	
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
